README: catalog folder. Search in src/catalog/ for listFilter.
Read src/catalog/listFilter.ts.