Read README.md layout — src/server.ts listed for HTTP.
Read src/server.ts — production entry (skipped devServer note in README).